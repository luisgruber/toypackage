test_that("f works", {
  res <- f(1,1)
  expect_equal(res, 2)
})
